<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();
$manifest['id'] = 'somo';
$manifest['supported_extensions'] = array(
	'backups' => array(),
	'portfolio' => array(),
	'megamenu' => array(),
);